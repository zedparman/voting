const Votes = () => {
    return (
        <div>
            <p>Votes page</p>
        </div>
    )
}

export default Votes;