const CreateVote = () => {
    return (
        <div>
            <p>Create vote page</p>
        </div>
    )
}

export default CreateVote;